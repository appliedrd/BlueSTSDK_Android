package com.st.BlueMS.physiobiometrics.shimmer;

public class StepCalculations {
    int frequency;
    double rate;
    int goodsteps;
    int badsteps;
    int nSteps;
    double totalTime;
    double goodpercent;
    double badpercent;
    double stepwalkingtime;
    double totalwalkingtime;
    double startWalking;
    double avgstep;
    double avgCadence;
    double meanAngularVelocity;
    double stdAngularVelocity;
    double coefVariation;

    StepCalculations() {
        frequency =0;
        rate =0;
        goodsteps=0;
        badsteps=0;
        int nSteps;
        double totalTime;
        double goodpercent;
        double badpercent;
        double stepwalkingtime;
        double totalwalkingtime;
        double startWalking;
        double avgstep;
        double avgCadence;
        double meanAngularVelocity;
        double stdAngularVelocity;
        double coefVariation;
    }


}
