package com.st.BlueMS.demos.util;


import com.st.BlueSTSDK.gui.demos.DemoFragment;

public abstract class BaseDemoFragment extends DemoFragment {
}
